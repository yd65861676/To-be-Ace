# Render.com 部署指南

## 部署准备

我已经为您准备了在Render.com上部署数字画作交易平台所需的所有配置文件：

1. **render.yaml** - Render服务配置文件
2. **build.sh** - 构建脚本（安装依赖和准备环境）
3. **run.sh** - 运行脚本（启动应用服务器）

这些文件已经配置好，无需修改即可使用。

## 部署步骤

### 1. 注册Render账户

1. 访问 [Render.com](https://render.com/)
2. 点击"Sign Up"注册账户（可以使用GitHub、GitLab或Google账户快速注册）

### 2. 准备代码仓库

您有两种方式上传代码：

**方式一：通过GitHub/GitLab（推荐）**
1. 在GitHub或GitLab创建一个新仓库
2. 将项目文件上传到该仓库
3. 确保包含所有配置文件（render.yaml、build.sh、run.sh）

**方式二：直接上传到Render**
1. 将项目文件打包成ZIP文件
2. 在Render创建服务时选择"Upload Files"选项

### 3. 创建Web服务

1. 登录Render后，点击控制面板中的"New +"按钮
2. 选择"Web Service"
3. 如果使用GitHub/GitLab，选择您的仓库；如果直接上传，选择"Upload Files"
4. 填写服务信息：
   - **Name**: digital-art-marketplace（或您喜欢的名称）
   - **Environment**: Python 3
   - **Build Command**: ./build.sh
   - **Start Command**: ./run.sh
5. 选择"Free"计划
6. 点击"Create Web Service"

### 4. 配置环境变量

服务创建后，前往"Environment"选项卡，确认以下环境变量已设置（render.yaml中已包含）：
- `FLASK_APP=src.main`
- `FLASK_ENV=production`
- `SECRET_KEY`（自动生成）

### 5. 等待部署完成

Render会自动开始构建和部署过程，这可能需要几分钟时间。您可以在"Logs"选项卡中查看部署进度。

### 6. 访问您的应用

部署完成后，Render会提供一个URL（如`https://digital-art-marketplace.onrender.com`）。点击该URL即可访问您的应用。

## 注意事项

1. **数据库**: Render免费计划不包含持久化数据库。应用默认使用SQLite，但数据可能在服务重启后丢失。如需持久化存储，可以：
   - 升级到Render付费计划
   - 使用外部数据库服务（如ElephantSQL的免费PostgreSQL）

2. **休眠策略**: Render免费计划的服务在15分钟无活动后会休眠，首次访问时可能需要等待几秒钟唤醒。

3. **资源限制**: 免费计划有CPU和内存限制，适合低到中等流量的应用。

4. **文件存储**: 上传的图片存储在应用内，如果需要更可靠的存储，建议使用云存储服务（如AWS S3）。

## 故障排除

如果部署过程中遇到问题：

1. 检查"Logs"选项卡中的错误信息
2. 确认所有配置文件（render.yaml、build.sh、run.sh）都已正确上传
3. 确认build.sh和run.sh有执行权限

如需进一步帮助，请随时联系我。
