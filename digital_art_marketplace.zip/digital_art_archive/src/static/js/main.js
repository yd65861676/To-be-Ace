// 主要JavaScript文件
document.addEventListener('DOMContentLoaded', function() {
    // 检查用户登录状态
    checkAuthStatus();
    
    // 路由处理
    handleRouting();
    
    // 注册事件监听器
    document.getElementById('logout-btn').addEventListener('click', logout);
});

// 检查用户登录状态
function checkAuthStatus() {
    fetch('/api/auth/check')
        .then(response => response.json())
        .then(data => {
            if (data.authenticated) {
                // 用户已登录
                document.getElementById('auth-buttons').classList.add('d-none');
                document.getElementById('user-menu').classList.remove('d-none');
                document.getElementById('username').textContent = data.user.username;
                
                // 如果是管理员，添加管理员菜单
                if (data.user.is_admin) {
                    const dropdown = document.querySelector('#userDropdown + .dropdown-menu');
                    const divider = dropdown.querySelector('.dropdown-divider');
                    
                    const adminItem = document.createElement('li');
                    adminItem.innerHTML = '<a class="dropdown-item" href="/admin">管理后台</a>';
                    
                    dropdown.insertBefore(adminItem, divider);
                }
            } else {
                // 用户未登录
                document.getElementById('auth-buttons').classList.remove('d-none');
                document.getElementById('user-menu').classList.add('d-none');
            }
        })
        .catch(error => {
            console.error('检查登录状态出错:', error);
        });
}

// 路由处理
function handleRouting() {
    const path = window.location.pathname;
    const appContainer = document.getElementById('app');
    
    switch (path) {
        case '/':
            loadHomePage(appContainer);
            break;
        case '/gallery':
            loadGalleryPage(appContainer);
            break;
        case '/login':
            loadLoginPage(appContainer);
            break;
        case '/register':
            loadRegisterPage(appContainer);
            break;
        case '/profile':
            loadProfilePage(appContainer);
            break;
        case '/upload':
            loadUploadPage(appContainer);
            break;
        case '/my-artworks':
            loadMyArtworksPage(appContainer);
            break;
        case '/my-orders':
            loadMyOrdersPage(appContainer);
            break;
        case '/admin':
            loadAdminPage(appContainer);
            break;
        case '/about':
            loadAboutPage(appContainer);
            break;
        default:
            if (path.startsWith('/artwork/')) {
                const artworkId = path.split('/').pop();
                loadArtworkDetailPage(appContainer, artworkId);
            } else if (path.startsWith('/certificate/')) {
                const certificateId = path.split('/').pop();
                loadCertificateDetailPage(appContainer, certificateId);
            } else {
                loadNotFoundPage(appContainer);
            }
    }
}

// 加载首页
function loadHomePage(container) {
    container.innerHTML = `
        <div class="container">
            <div id="homeCarousel" class="carousel slide mb-5" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#homeCarousel" data-bs-slide-to="0" class="active"></button>
                    <button type="button" data-bs-target="#homeCarousel" data-bs-slide-to="1"></button>
                    <button type="button" data-bs-target="#homeCarousel" data-bs-slide-to="2"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="https://source.unsplash.com/random/1200x400/?art,painting" class="d-block w-100" alt="艺术作品">
                        <div class="carousel-caption d-none d-md-block">
                            <h2>将您的画作转换为数字资产</h2>
                            <p>独特的数字凭证，确保您的艺术品价值</p>
                            <a href="/register" class="btn btn-primary">立即注册</a>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="https://source.unsplash.com/random/1200x400/?digital,art" class="d-block w-100" alt="数字艺术">
                        <div class="carousel-caption d-none d-md-block">
                            <h2>探索数字艺术世界</h2>
                            <p>浏览独特的数字化艺术作品</p>
                            <a href="/gallery" class="btn btn-primary">浏览画廊</a>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="https://source.unsplash.com/random/1200x400/?gallery,exhibition" class="d-block w-100" alt="艺术展览">
                        <div class="carousel-caption d-none d-md-block">
                            <h2>安全可靠的交易平台</h2>
                            <p>支持微信支付，便捷安全</p>
                            <a href="/about" class="btn btn-primary">了解更多</a>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#homeCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                    <span class="visually-hidden">上一个</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#homeCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                    <span class="visually-hidden">下一个</span>
                </button>
            </div>
            
            <div class="row mb-5">
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="bi bi-cloud-upload fs-1 text-primary mb-3"></i>
                            <h3 class="card-title">上传您的画作</h3>
                            <p class="card-text">将您的实体画作上传到我们的平台，我们将为您创建独特的数字资产凭证。</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="bi bi-shield-check fs-1 text-primary mb-3"></i>
                            <h3 class="card-title">获得数字凭证</h3>
                            <p class="card-text">每件作品都会获得唯一的数字凭证，确保您的艺术品的真实性和唯一性。</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="bi bi-currency-exchange fs-1 text-primary mb-3"></i>
                            <h3 class="card-title">安全交易</h3>
                            <p class="card-text">通过我们的平台安全地买卖数字化艺术品，支持微信支付。</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <h2 class="text-center mb-4">最新上架</h2>
            <div class="row" id="latest-artworks">
                <p class="text-center">加载中...</p>
            </div>
            <div class="text-center mt-4">
                <a href="/gallery" class="btn btn-outline-primary">查看更多</a>
            </div>
        </div>
    `;
    
    // 加载最新画作
    loadLatestArtworks();
}

// 加载最新画作
function loadLatestArtworks() {
    fetch('/api/artworks')
        .then(response => response.json())
        .then(artworks => {
            const container = document.getElementById('latest-artworks');
            
            if (artworks.length === 0) {
                container.innerHTML = '<p class="text-center">暂无画作</p>';
                return;
            }
            
            container.innerHTML = '';
            
            // 只显示最新的6件作品
            const latestArtworks = artworks.slice(0, 6);
            
            latestArtworks.forEach(artwork => {
                const artworkCard = document.createElement('div');
                artworkCard.className = 'col-md-4 gallery-item';
                artworkCard.innerHTML = `
                    <div class="card">
                        <img src="${artwork.image_path}" class="card-img-top" alt="${artwork.title}">
                        ${artwork.digital_certificate ? '<span class="certificate-badge">数字凭证</span>' : ''}
                        <div class="card-body">
                            <h5 class="card-title">${artwork.title}</h5>
                            <p class="card-text">${artwork.description.substring(0, 100)}${artwork.description.length > 100 ? '...' : ''}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="text-primary fw-bold">¥${artwork.price.toFixed(2)}</span>
                                <a href="/artwork/${artwork.id}" class="btn btn-sm btn-outline-primary">查看详情</a>
                            </div>
                        </div>
                    </div>
                `;
                container.appendChild(artworkCard);
            });
        })
        .catch(error => {
            console.error('加载最新画作出错:', error);
            document.getElementById('latest-artworks').innerHTML = '<p class="text-center text-danger">加载画作失败，请稍后再试</p>';
        });
}

// 登出功能
function logout() {
    fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        window.location.href = '/';
    })
    .catch(error => {
        console.error('登出出错:', error);
    });
}

// 其他页面加载函数
function loadGalleryPage(container) {
    // 实现画廊页面
    container.innerHTML = `
        <div class="container">
            <h1 class="text-center mb-5">艺术品画廊</h1>
            <div class="row mb-4">
                <div class="col-md-6 offset-md-3">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="搜索艺术品..." id="search-input">
                        <button class="btn btn-primary" type="button" id="search-button">搜索</button>
                    </div>
                </div>
            </div>
            <div class="row" id="gallery-container">
                <p class="text-center">加载中...</p>
            </div>
        </div>
    `;
    
    // 加载所有画作
    fetch('/api/artworks')
        .then(response => response.json())
        .then(artworks => {
            const container = document.getElementById('gallery-container');
            
            if (artworks.length === 0) {
                container.innerHTML = '<p class="text-center">暂无画作</p>';
                return;
            }
            
            container.innerHTML = '';
            
            artworks.forEach(artwork => {
                const artworkCard = document.createElement('div');
                artworkCard.className = 'col-md-4 gallery-item';
                artworkCard.innerHTML = `
                    <div class="card">
                        <img src="${artwork.image_path}" class="card-img-top" alt="${artwork.title}">
                        ${artwork.digital_certificate ? '<span class="certificate-badge">数字凭证</span>' : ''}
                        <div class="card-body">
                            <h5 class="card-title">${artwork.title}</h5>
                            <p class="card-text">${artwork.description.substring(0, 100)}${artwork.description.length > 100 ? '...' : ''}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="text-primary fw-bold">¥${artwork.price.toFixed(2)}</span>
                                <a href="/artwork/${artwork.id}" class="btn btn-sm btn-outline-primary">查看详情</a>
                            </div>
                        </div>
                    </div>
                `;
                container.appendChild(artworkCard);
            });
        })
        .catch(error => {
            console.error('加载画作出错:', error);
            document.getElementById('gallery-container').innerHTML = '<p class="text-center text-danger">加载画作失败，请稍后再试</p>';
        });
}

function loadLoginPage(container) {
    container.innerHTML = `
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="card-title text-center mb-4">用户登录</h2>
                            <div id="login-alert" class="alert alert-danger d-none"></div>
                            <form id="login-form">
                                <div class="mb-3">
                                    <label for="username" class="form-label">用户名</label>
                                    <input type="text" class="form-control" id="username" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">密码</label>
                                    <input type="password" class="form-control" id="password" required>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">登录</button>
                                </div>
                            </form>
                            <div class="text-center mt-3">
                                <p>还没有账号？<a href="/register">立即注册</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // 添加登录表单提交事件
    document.getElementById('login-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                const alertBox = document.getElementById('login-alert');
                alertBox.textContent = data.error;
                alertBox.classList.remove('d-none');
            } else {
                window.location.href = '/';
            }
        })
        .catch(error => {
            console.error('登录出错:', error);
            const alertBox = document.getElementById('login-alert');
            alertBox.textContent = '登录失败，请稍后再试';
            alertBox.classList.remove('d-none');
        });
    });
}

function loadRegisterPage(container) {
    container.innerHTML = `
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="card-title text-center mb-4">用户注册</h2>
                            <div id="register-alert" class="alert alert-danger d-none"></div>
                            <form id="register-form">
                                <div class="mb-3">
                                    <label for="username" class="form-label">用户名</label>
                                    <input type="text" class="form-control" id="username" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">电子邮箱</label>
                                    <input type="email" class="form-control" id="email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">密码</label>
                                    <input type="password" class="form-control" id="password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="confirm-password" class="form-label">确认密码</label>
                                    <input type="password" class="form-control" id="confirm-password" required>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">注册</button>
                                </div>
                            </form>
                            <div class="text-center mt-3">
                                <p>已有账号？<a href="/login">立即登录</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // 添加注册表单提交事件
    document.getElementById('register-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        
        // 验证密码是否一致
        if (password !== confirmPassword) {
            const alertBox = document.getElementById('register-alert');
            alertBox.textContent = '两次输入的密码不一致';
            alertBox.classList.remove('d-none');
            return;
        }
        
        fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                const alertBox = document.getElementById('register-alert');
                alertBox.textContent = data.error;
                alertBox.classList.remove('d-none');
            } else {
                window.location.href = '/login';
            }
        })
        .catch(error => {
            console.error('注册出错:', error);
            const alertBox = document.getElementById('register-alert');
            alertBox.textContent = '注册失败，请稍后再试';
            alertBox.classList.remove('d-none');
        });
    });
}

// 其他页面加载函数可以根据需要继续实现
// 这里只实现了基本的页面，完整项目需要实现所有页面

// 加载404页面
function loadNotFoundPage(container) {
    container.innerHTML = `
        <div class="container text-center py-5">
            <h1 class="display-1">404</h1>
            <h2>页面未找到</h2>
            <p>您访问的页面不存在或已被移除。</p>
            <a href="/" class="btn btn-primary">返回首页</a>
        </div>
    `;
}
