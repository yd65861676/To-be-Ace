from src.models.user import db, User
from src.models.artwork import Artwork
from src.models.order import Order
from src.models.certificate import DigitalCertificate

# 确保所有模型都被导入，以便在创建数据库表时能够正确识别
