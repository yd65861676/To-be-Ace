from flask_sqlalchemy import SQLAlchemy
import uuid

db = SQLAlchemy()

class DigitalCertificate(db.Model):
    __tablename__ = 'digital_certificates'
    
    id = db.Column(db.Integer, primary_key=True)
    certificate_id = db.Column(db.String(100), unique=True, nullable=False)
    artwork_id = db.Column(db.Integer, db.ForeignKey('artworks.id'), nullable=False)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    issue_date = db.Column(db.DateTime, server_default=db.func.now())
    meta_info = db.Column(db.Text)  # 存储JSON格式的元数据，避免使用保留字metadata
    
    def __repr__(self):
        return f'<DigitalCertificate {self.certificate_id}>'
    
    @staticmethod
    def generate_certificate_id():
        """生成唯一的数字凭证ID"""
        return str(uuid.uuid4())
