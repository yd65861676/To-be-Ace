from flask import Blueprint, request, jsonify, session
from src.models.order import Order, db
from src.models.artwork import Artwork
from src.models.certificate import DigitalCertificate
import uuid
from datetime import datetime
import json
import hashlib
import time
import random
import string

order_bp = Blueprint('order', __name__)

# 检查用户是否已登录
def login_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': '请先登录'}), 401
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def generate_order_number():
    """生成唯一的订单号"""
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"ORD{timestamp}{random_str}"

@order_bp.route('/', methods=['GET'])
@login_required
def get_orders():
    """获取当前用户的订单列表"""
    user_id = session['user_id']
    is_admin = session.get('is_admin', False)
    
    # 管理员可以查看所有订单，普通用户只能查看自己的订单
    if is_admin:
        orders = Order.query.all()
    else:
        orders = Order.query.filter_by(user_id=user_id).all()
    
    result = []
    for order in orders:
        artwork = Artwork.query.get(order.artwork_id)
        result.append({
            'id': order.id,
            'order_number': order.order_number,
            'artwork_id': order.artwork_id,
            'artwork_title': artwork.title if artwork else None,
            'amount': order.amount,
            'status': order.status,
            'created_at': order.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify(result), 200

@order_bp.route('/<int:order_id>', methods=['GET'])
@login_required
def get_order(order_id):
    """获取订单详情"""
    order = Order.query.get_or_404(order_id)
    
    # 检查是否是订单的所有者或管理员
    if order.user_id != session['user_id'] and not session.get('is_admin', False):
        return jsonify({'error': '没有权限查看此订单'}), 403
    
    artwork = Artwork.query.get(order.artwork_id)
    
    result = {
        'id': order.id,
        'order_number': order.order_number,
        'artwork_id': order.artwork_id,
        'artwork_title': artwork.title if artwork else None,
        'artwork_image': artwork.image_path if artwork else None,
        'amount': order.amount,
        'status': order.status,
        'payment_id': order.payment_id,
        'created_at': order.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        'updated_at': order.updated_at.strftime('%Y-%m-%d %H:%M:%S')
    }
    
    return jsonify(result), 200

@order_bp.route('/', methods=['POST'])
@login_required
def create_order():
    """创建新订单"""
    data = request.get_json()
    
    # 验证必填字段
    if 'artwork_id' not in data:
        return jsonify({'error': '画作ID为必填项'}), 400
    
    # 查找画作
    artwork = Artwork.query.get_or_404(data['artwork_id'])
    
    # 检查画作是否已售出
    if artwork.is_sold:
        return jsonify({'error': '该画作已售出'}), 400
    
    # 创建订单
    order_number = generate_order_number()
    new_order = Order(
        order_number=order_number,
        user_id=session['user_id'],
        artwork_id=artwork.id,
        amount=artwork.price,
        status='pending'
    )
    
    # 保存到数据库
    db.session.add(new_order)
    db.session.commit()
    
    # 生成微信支付参数（模拟）
    # 实际项目中，这里应该调用微信支付API生成支付参数
    payment_params = {
        'order_number': order_number,
        'amount': artwork.price,
        'timestamp': int(time.time()),
        'nonce_str': ''.join(random.choices(string.ascii_letters + string.digits, k=16)),
        'body': f"数字画作 - {artwork.title}"
    }
    
    # 生成签名（模拟）
    sign_str = '&'.join([f"{k}={v}" for k, v in sorted(payment_params.items())])
    payment_params['sign'] = hashlib.md5(sign_str.encode()).hexdigest().upper()
    
    return jsonify({
        'message': '订单创建成功',
        'order_id': new_order.id,
        'order_number': order_number,
        'payment_params': payment_params
    }), 201

@order_bp.route('/pay/<int:order_id>', methods=['POST'])
@login_required
def pay_order(order_id):
    """支付订单（模拟支付成功）"""
    order = Order.query.get_or_404(order_id)
    
    # 检查是否是订单的所有者
    if order.user_id != session['user_id']:
        return jsonify({'error': '没有权限支付此订单'}), 403
    
    # 检查订单状态
    if order.status != 'pending':
        return jsonify({'error': f'订单状态为{order.status}，无法支付'}), 400
    
    # 模拟支付成功
    payment_id = f"WX{int(time.time())}{random.randint(1000, 9999)}"
    
    # 更新订单状态
    order.status = 'paid'
    order.payment_id = payment_id
    order.updated_at = datetime.utcnow()
    
    # 更新画作状态为已售出
    artwork = Artwork.query.get(order.artwork_id)
    if artwork:
        artwork.is_sold = True
    
    # 更新数字凭证所有者
    certificate = DigitalCertificate.query.filter_by(artwork_id=order.artwork_id).first()
    if certificate:
        certificate.owner_id = order.user_id
        
        # 更新元数据
        metadata = json.loads(certificate.meta_info) if certificate.meta_info else {}
        metadata['transfer_history'] = metadata.get('transfer_history', [])
        metadata['transfer_history'].append({
            'from_user_id': artwork.user_id,
            'to_user_id': order.user_id,
            'transfer_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'transaction_id': payment_id
        })
        certificate.meta_info = json.dumps(metadata)
    
    # 保存到数据库
    db.session.commit()
    
    return jsonify({
        'message': '支付成功',
        'order_status': 'paid',
        'payment_id': payment_id
    }), 200

@order_bp.route('/<int:order_id>/cancel', methods=['POST'])
@login_required
def cancel_order(order_id):
    """取消订单"""
    order = Order.query.get_or_404(order_id)
    
    # 检查是否是订单的所有者或管理员
    if order.user_id != session['user_id'] and not session.get('is_admin', False):
        return jsonify({'error': '没有权限取消此订单'}), 403
    
    # 检查订单状态
    if order.status != 'pending':
        return jsonify({'error': f'订单状态为{order.status}，无法取消'}), 400
    
    # 更新订单状态
    order.status = 'cancelled'
    order.updated_at = datetime.utcnow()
    
    # 保存到数据库
    db.session.commit()
    
    return jsonify({
        'message': '订单已取消',
        'order_status': 'cancelled'
    }), 200
