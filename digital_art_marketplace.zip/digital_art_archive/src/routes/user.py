from flask import Blueprint, jsonify, session, request
from src.models.user import User, db

user_bp = Blueprint('user', __name__)

# 检查用户是否已登录
def login_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': '请先登录'}), 401
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@user_bp.route('/profile', methods=['GET'])
@login_required
def get_profile():
    """获取当前用户的个人资料"""
    user_id = session['user_id']
    user = User.query.get_or_404(user_id)
    
    return jsonify({
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'is_admin': user.is_admin,
        'created_at': user.created_at.strftime('%Y-%m-%d %H:%M:%S')
    }), 200

@user_bp.route('/profile', methods=['PUT'])
@login_required
def update_profile():
    """更新当前用户的个人资料"""
    user_id = session['user_id']
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    # 更新字段
    if 'email' in data:
        # 检查邮箱是否已被其他用户使用
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user and existing_user.id != user_id:
            return jsonify({'error': '该邮箱已被使用'}), 400
        user.email = data['email']
    
    # 保存到数据库
    db.session.commit()
    
    return jsonify({'message': '个人资料更新成功'}), 200
