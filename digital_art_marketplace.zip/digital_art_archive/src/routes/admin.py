from flask import Blueprint, request, jsonify, session
from src.models.user import User, db
from src.models.artwork import Artwork
from src.models.order import Order

admin_bp = Blueprint('admin', __name__)

# 检查用户是否是管理员
def admin_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': '请先登录'}), 401
        if not session.get('is_admin', False):
            return jsonify({'error': '需要管理员权限'}), 403
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@admin_bp.route('/users', methods=['GET'])
@admin_required
def get_users():
    """获取所有用户列表（管理员专用）"""
    users = User.query.all()
    result = []
    
    for user in users:
        result.append({
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'is_admin': user.is_admin,
            'created_at': user.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify(result), 200

@admin_bp.route('/users/<int:user_id>', methods=['PUT'])
@admin_required
def update_user(user_id):
    """更新用户信息（管理员专用）"""
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    # 更新字段
    if 'is_admin' in data:
        user.is_admin = bool(data['is_admin'])
    
    # 保存到数据库
    db.session.commit()
    
    return jsonify({'message': '用户信息更新成功'}), 200

@admin_bp.route('/artworks', methods=['GET'])
@admin_required
def get_all_artworks():
    """获取所有画作列表（管理员专用）"""
    artworks = Artwork.query.all()
    result = []
    
    for artwork in artworks:
        result.append({
            'id': artwork.id,
            'title': artwork.title,
            'description': artwork.description,
            'image_path': artwork.image_path,
            'price': artwork.price,
            'user_id': artwork.user_id,
            'is_sold': artwork.is_sold,
            'digital_certificate': artwork.digital_certificate,
            'created_at': artwork.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify(result), 200

@admin_bp.route('/orders', methods=['GET'])
@admin_required
def get_all_orders():
    """获取所有订单列表（管理员专用）"""
    orders = Order.query.all()
    result = []
    
    for order in orders:
        artwork = Artwork.query.get(order.artwork_id)
        user = User.query.get(order.user_id)
        
        result.append({
            'id': order.id,
            'order_number': order.order_number,
            'user_id': order.user_id,
            'username': user.username if user else None,
            'artwork_id': order.artwork_id,
            'artwork_title': artwork.title if artwork else None,
            'amount': order.amount,
            'status': order.status,
            'payment_id': order.payment_id,
            'created_at': order.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': order.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify(result), 200

@admin_bp.route('/dashboard', methods=['GET'])
@admin_required
def get_dashboard():
    """获取管理员仪表盘数据"""
    # 统计用户数量
    user_count = User.query.count()
    
    # 统计画作数量
    artwork_count = Artwork.query.count()
    artwork_sold_count = Artwork.query.filter_by(is_sold=True).count()
    
    # 统计订单数量和总金额
    order_count = Order.query.count()
    order_paid_count = Order.query.filter_by(status='paid').count()
    
    # 计算总销售额
    total_sales = db.session.query(db.func.sum(Order.amount)).filter(Order.status == 'paid').scalar() or 0
    
    return jsonify({
        'user_count': user_count,
        'artwork_count': artwork_count,
        'artwork_sold_count': artwork_sold_count,
        'artwork_sold_percentage': round(artwork_sold_count / artwork_count * 100, 2) if artwork_count > 0 else 0,
        'order_count': order_count,
        'order_paid_count': order_paid_count,
        'order_paid_percentage': round(order_paid_count / order_count * 100, 2) if order_count > 0 else 0,
        'total_sales': float(total_sales)
    }), 200
