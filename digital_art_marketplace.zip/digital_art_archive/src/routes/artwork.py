from flask import Blueprint, request, jsonify, session, current_app
from werkzeug.utils import secure_filename
import os
import uuid
from datetime import datetime
from src.models.artwork import Artwork, db
from src.models.certificate import DigitalCertificate
import json

artwork_bp = Blueprint('artwork', __name__)

# 检查用户是否已登录
def login_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': '请先登录'}), 401
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

# 检查文件扩展名是否允许
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@artwork_bp.route('/', methods=['GET'])
def get_artworks():
    """获取所有画作列表"""
    artworks = Artwork.query.all()
    result = []
    
    for artwork in artworks:
        result.append({
            'id': artwork.id,
            'title': artwork.title,
            'description': artwork.description,
            'image_path': artwork.image_path,
            'price': artwork.price,
            'is_sold': artwork.is_sold,
            'created_at': artwork.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify(result), 200

@artwork_bp.route('/<int:artwork_id>', methods=['GET'])
def get_artwork(artwork_id):
    """获取单个画作详情"""
    artwork = Artwork.query.get_or_404(artwork_id)
    
    # 查询该画作的数字凭证
    certificate = DigitalCertificate.query.filter_by(artwork_id=artwork.id).first()
    certificate_id = certificate.certificate_id if certificate else None
    
    result = {
        'id': artwork.id,
        'title': artwork.title,
        'description': artwork.description,
        'image_path': artwork.image_path,
        'price': artwork.price,
        'is_sold': artwork.is_sold,
        'digital_certificate': certificate_id,
        'created_at': artwork.created_at.strftime('%Y-%m-%d %H:%M:%S')
    }
    
    return jsonify(result), 200

@artwork_bp.route('/', methods=['POST'])
@login_required
def upload_artwork():
    """上传新画作"""
    # 检查是否有文件
    if 'image' not in request.files:
        return jsonify({'error': '没有上传文件'}), 400
    
    file = request.files['image']
    
    # 检查文件名是否为空
    if file.filename == '':
        return jsonify({'error': '未选择文件'}), 400
    
    # 检查文件类型
    if not allowed_file(file.filename):
        return jsonify({'error': '不支持的文件类型，请上传png、jpg、jpeg或gif格式的图片'}), 400
    
    # 获取表单数据
    title = request.form.get('title')
    description = request.form.get('description', '')
    price = request.form.get('price')
    
    # 验证必填字段
    if not title or not price:
        return jsonify({'error': '标题和价格为必填项'}), 400
    
    try:
        price = float(price)
    except ValueError:
        return jsonify({'error': '价格必须是数字'}), 400
    
    # 保存文件
    filename = secure_filename(file.filename)
    # 添加时间戳和随机字符串，确保文件名唯一
    unique_filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:8]}_{filename}"
    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], unique_filename)
    file.save(file_path)
    
    # 相对路径，用于前端显示
    relative_path = f"/static/uploads/{unique_filename}"
    
    # 创建新画作记录
    new_artwork = Artwork(
        title=title,
        description=description,
        image_path=relative_path,
        price=price,
        user_id=session['user_id']
    )
    
    # 保存到数据库
    db.session.add(new_artwork)
    db.session.commit()
    
    # 生成数字凭证
    certificate_id = DigitalCertificate.generate_certificate_id()
    
    # 创建元数据
    metadata = {
        'artwork_id': new_artwork.id,
        'title': title,
        'artist_id': session['user_id'],
        'creation_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'image_hash': certificate_id  # 简化处理，实际应计算图像哈希
    }
    
    # 创建数字凭证记录
    new_certificate = DigitalCertificate(
        certificate_id=certificate_id,
        artwork_id=new_artwork.id,
        owner_id=session['user_id'],
        meta_info=json.dumps(metadata)
    )
    
    # 更新画作的数字凭证字段
    new_artwork.digital_certificate = certificate_id
    
    # 保存到数据库
    db.session.add(new_certificate)
    db.session.commit()
    
    return jsonify({
        'message': '画作上传成功',
        'artwork_id': new_artwork.id,
        'digital_certificate': certificate_id
    }), 201

@artwork_bp.route('/<int:artwork_id>', methods=['PUT'])
@login_required
def update_artwork(artwork_id):
    """更新画作信息"""
    artwork = Artwork.query.get_or_404(artwork_id)
    
    # 检查是否是画作的所有者或管理员
    if artwork.user_id != session['user_id'] and not session.get('is_admin', False):
        return jsonify({'error': '没有权限修改此画作'}), 403
    
    data = request.get_json()
    
    # 更新字段
    if 'title' in data:
        artwork.title = data['title']
    if 'description' in data:
        artwork.description = data['description']
    if 'price' in data and not artwork.is_sold:
        try:
            artwork.price = float(data['price'])
        except ValueError:
            return jsonify({'error': '价格必须是数字'}), 400
    
    # 保存到数据库
    db.session.commit()
    
    return jsonify({'message': '画作信息更新成功'}), 200

@artwork_bp.route('/<int:artwork_id>', methods=['DELETE'])
@login_required
def delete_artwork(artwork_id):
    """删除画作"""
    artwork = Artwork.query.get_or_404(artwork_id)
    
    # 检查是否是画作的所有者或管理员
    if artwork.user_id != session['user_id'] and not session.get('is_admin', False):
        return jsonify({'error': '没有权限删除此画作'}), 403
    
    # 如果画作已售出，不允许删除
    if artwork.is_sold:
        return jsonify({'error': '已售出的画作不能删除'}), 400
    
    # 删除关联的数字凭证
    certificate = DigitalCertificate.query.filter_by(artwork_id=artwork.id).first()
    if certificate:
        db.session.delete(certificate)
    
    # 删除画作文件
    if artwork.image_path and os.path.exists(os.path.join(current_app.static_folder, artwork.image_path.lstrip('/'))):
        os.remove(os.path.join(current_app.static_folder, artwork.image_path.lstrip('/')))
    
    # 删除画作记录
    db.session.delete(artwork)
    db.session.commit()
    
    return jsonify({'message': '画作删除成功'}), 200

@artwork_bp.route('/certificate/<certificate_id>', methods=['GET'])
def get_certificate(certificate_id):
    """获取数字凭证详情"""
    certificate = DigitalCertificate.query.filter_by(certificate_id=certificate_id).first_or_404()
    artwork = Artwork.query.get(certificate.artwork_id)
    
    result = {
        'certificate_id': certificate.certificate_id,
        'artwork_id': certificate.artwork_id,
        'artwork_title': artwork.title if artwork else None,
        'owner_id': certificate.owner_id,
        'issue_date': certificate.issue_date.strftime('%Y-%m-%d %H:%M:%S'),
        'metadata': json.loads(certificate.meta_info) if certificate.meta_info else {}
    }
    
    return jsonify(result), 200
